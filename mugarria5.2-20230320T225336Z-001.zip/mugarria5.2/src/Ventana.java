import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Ventana extends JFrame implements ActionListener {
    private JComboBox<String> comboBox;
    private JTextArea textArea;
    private JButton btnBorrar;
    private JButton btnCerrar;
    private String[] nombresArchivos = {"Python", "C", "Java"};
    private String[] contenidos = {
            "Python es un lenguaje de programación interpretado de alto nivel, diseñado para ser fácilmente legible y mantenible. Se utiliza en una variedad de aplicaciones, incluyendo ciencia de datos, inteligencia artificial y desarrollo web.",
            "C es un lenguaje de programación de bajo nivel, diseñado para ser altamente eficiente y para permitir un control preciso sobre el hardware de la computadora. Se utiliza en una variedad de aplicaciones, incluyendo sistemas operativos, bases de datos y controladores de dispositivos.",
            "Java es un lenguaje de programación orientado a objetos, diseñado para ser altamente portátil y para permitir el desarrollo de aplicaciones seguras y confiables. Se utiliza en una variedad de aplicaciones, incluyendo aplicaciones empresariales, aplicaciones móviles y aplicaciones web."};

    public Ventana() {
        // Configuración de la ventana principal
        this.setTitle("Información sobre lenguajes de programación");
        this.setSize(500, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Configuración del panel principal
        JPanel panel = new JPanel(new BorderLayout());

        // Configuración del JComboBox
        comboBox = new JComboBox<String>(nombresArchivos);
        comboBox.addActionListener(this);
        panel.add(comboBox, BorderLayout.NORTH);

        // Configuración del JTextArea
        textArea = new JTextArea();
        panel.add(textArea, BorderLayout.CENTER);

        // Configuración del botón "Borrar"
        btnBorrar = new JButton("Borrar");
        btnBorrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textArea.setText("");
            }
        });
        panel.add(btnBorrar, BorderLayout.SOUTH);

        // Configuración del botón "Cerrar"
        btnCerrar = new JButton("Cerrar");
        btnCerrar.addActionListener(this);
        panel.add(btnCerrar, BorderLayout.EAST);

        // Agregar el panel principal a la ventana
        this.add(panel);

        // Hacer visible la ventana
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == comboBox) {
            // Obtener el índice del elemento seleccionado en el JComboBox
            int index = comboBox.getSelectedIndex();

            // Obtener el contenido correspondiente al elemento seleccionado
            String contenido = contenidos[index];

            // Mostrar el contenido en el JTextArea
            textArea.setText(contenido);
        } else if (e.getSource() == btnCerrar) {
            // Cerrar la ventana
            this.dispose();
        }
    }

    public static void main(String[] args) {
        new Ventana();
    }
}


