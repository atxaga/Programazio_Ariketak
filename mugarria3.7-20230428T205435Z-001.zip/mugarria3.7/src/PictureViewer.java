import org.jdesktop.swingx.JXDatePicker;

import javax.swing.*;
import java.awt.*;

public class PictureViewer extends JFrame {

    private JComboBox<String> comboBox;

    private JXDatePicker datePicker;
    private JLabel jLabel;
    private JList list;
    private String[] nombreFotografos = {"Ansel Adams","Rothko","Vangogh"};

    public PictureViewer() {

        //configuracion de ventana
        this.setTitle("Photografhy");
        this.setSize(500, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        //configuracion panel principal
        JPanel Panel = new JPanel(new BorderLayout());

        //Panel combobox
        JPanel conboBoxPanel = new JPanel(new BorderLayout());
        Panel.add(conboBoxPanel, BorderLayout.WEST);

        //Configuracion del combobox
        comboBox = new JComboBox<String>(nombreFotografos);
        comboBox.setSize(100, 100);
        jLabel = new JLabel("Fotografo: ");
        conboBoxPanel.add(jLabel, BorderLayout.NORTH);
        conboBoxPanel.add(comboBox, BorderLayout.CENTER);

        //Panel JXDatePicker
        JPanel jdate = new JPanel(new BorderLayout());
        Panel.add(jdate, BorderLayout.EAST);

        //Configuracion del JXDatePicker
        datePicker = new JXDatePicker();
        datePicker.setSize(150,150);
        jdate.add(datePicker, BorderLayout.CENTER);

        //Panel JList
        JPanel jlist = new JPanel(new BorderLayout());
        Panel.add(jlist, BorderLayout.SOUTH);
        
        //COnfiguracion del Jlist
        list = new JList<>();
        jlist.add(list, BorderLayout.SOUTH);



        this.add(Panel);



        this.setVisible(true);
    }

    public static void main(String[] args) {
        new PictureViewer();
    }
}

