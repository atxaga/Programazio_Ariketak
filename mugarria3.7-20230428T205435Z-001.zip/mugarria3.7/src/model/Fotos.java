package model;

public class Fotos {
}
